jpeg("pairplot.jpg")
pairs(Data,main="pairplot")
dev.off()

