load .r

source("pathname",echo=TRUE)
