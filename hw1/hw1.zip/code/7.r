Model<-svm(stdtrdata[1,,],trlabel[1,,],type="C-classification",kernel="linear",cost=1)
