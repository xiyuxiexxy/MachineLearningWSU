setwd("/home/xiyu/Downloads/570/code")
Data<-read.table("iris.data",sep=",")
colnames(Data)<- c( "Min" , "Max" ,  "Mean"  ,  "SD"  , "Class Correlation")
colnames(Data)

