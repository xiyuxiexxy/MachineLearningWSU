data<-data.matrix(Data[,1:4])
label<-data.matrix(Data[,5])
